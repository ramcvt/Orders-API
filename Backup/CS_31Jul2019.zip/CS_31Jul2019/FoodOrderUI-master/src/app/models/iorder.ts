import { OrdItems } from './ord-items';

export interface IOrder {
     emailID:string;
     restaurantName:string;
     deliveryAddress:string;
     billAmount:number;
     paymentMode:string;
     orderItems:OrdItems[];
}

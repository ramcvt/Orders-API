import { OrdItems } from './ord-items';

describe('OrdItems', () => {
  it('should create an instance', () => {
    expect(new OrdItems()).toBeTruthy();
  });
});

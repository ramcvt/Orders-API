import { Orders } from './orders';

describe('Orders', () => {
  it('should create an instance', () => {
    expect(new Orders()).toBeTruthy();
  });
});

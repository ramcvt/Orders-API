export class Restaurant {
    public id:string;
    public name:string;
    public location:string;
    public imageUrl:string;
    public contact:number;
    public availability:string;
    public rating:number;
}

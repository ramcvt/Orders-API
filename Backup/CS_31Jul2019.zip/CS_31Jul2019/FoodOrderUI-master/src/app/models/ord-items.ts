export class OrdItems {
    public itemName:string;
    public price:number;
    public quantity:number;
}

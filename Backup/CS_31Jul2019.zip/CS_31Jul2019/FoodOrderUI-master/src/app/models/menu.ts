export class Menu {
    public type:string;
    public subtype:string;
    public dish:string;
    public price:number;
    public availability:number;
}

import { Component, OnInit } from '@angular/core';

import { OrderService } from 'src/app/services/order.service';
import { Router } from '@angular/router';
import { CartService } from '../../services/cart.service';
import { Orders } from '../../models/orders';
import {IOrder} from '../../models/iorder';


@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
  public ordObj = new Orders(); 
  alertStatus = {
    success: false,
    submitted: false,
    message: ""
  }
  public order:any;
  public orders:Orders;
  public paymentMode:string;
  constructor( private ordSvc: OrderService,private cartSvc:CartService, private router: Router) {
    
   }
   
  ngOnInit() {
    this.order=this.cartSvc.getCartItems();

  }
  save(){
     let ord:IOrder = JSON.parse(this.order);
   
    this.paymentMode="Card";
    this.ordObj.EmailID=ord.emailID;
    this.ordObj.OrderDateTime=new Date().toLocaleDateString();
    this.ordObj.RestaurantName=ord.restaurantName;
    this.ordObj.DeliveryAddress=ord.deliveryAddress;
    this.ordObj.BillAmount=ord.billAmount;
    this.ordObj.PaymentMode=this.paymentMode;
    this.ordObj.orderItems=ord.orderItems;
    this.ordObj.OrderStatus="";

    this.orders=this.ordObj;

    this.ordSvc.saveOrder(this.orders)
    .subscribe(
      result => { this.router.navigate(['/orders']) },
      err => { console.log("Error", err) }
    );

    this.router.navigate(['/orders'])
  }
}

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RestaurantListComponent } from './components/restaurant-list/restaurant-list.component';
import { RestaurantDetailComponent } from './components/restaurant-detail/restaurant-detail.component';
import { OrderListComponent } from './components/order-list/order-list.component';
import { OrderDetailsComponent } from './components/order-details/order-details.component';
import { PaymentComponent } from './components/payment/payment.component';


const routes: Routes = [
  { path:"",component:RestaurantListComponent},
  { path:"restaurant/:id",component:RestaurantDetailComponent},
  { path:"orders",component:OrderListComponent},
  { path:"orders/:id",component:OrderDetailsComponent},
  { path:"payment",component:PaymentComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
